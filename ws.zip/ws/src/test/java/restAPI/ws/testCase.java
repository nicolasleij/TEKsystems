package restAPI.ws;

import static io.restassured.RestAssured.given;

import java.util.List;
import java.util.Scanner;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class testCase {

	@BeforeClass
	public void setup() {
		RestAssured.baseURI = "https://restcountries.eu/rest/v2";
	}

	@Test
	public void testByName() {
		Scanner sc = new Scanner(System.in);
		boolean input = true;
		while (input) {
			System.out.println("Please input city name or input 'quit' to leave:");
			String name = sc.nextLine();
			if (!name.toLowerCase().equals("quit")) {
				Response r = given().get("/name/" + name).then().extract().response();
				int code = r.getStatusCode();
				if (code == 200) {
					List<Object> countries = r.jsonPath().getList("name");
					List<Object> capitals = r.jsonPath().getList("capital");
					for (int i = 0; i < countries.size(); i++) {
						if (capitals.get(i).toString().length() != 0) {
							System.out.println("The capital of " + countries.get(i) + " is " + capitals.get(i) + ".");
						} else {
							System.out.println("The capital of " + countries.get(i) + " is not existed in the DB.");
						}
					}
				} else {
					System.out.println(
							"Please input existed city name. You could search by country name. It can be the native name or partial name.");
				}
			} else {
				input = false;
				System.out.println("Bye, thanks for your query.");
			}
		}
		sc.close();
	}

	@Test
	public void testByCode() {
		Scanner sc = new Scanner(System.in);
		boolean input = true;
		while (input) {
			System.out.println("Please input city code or input 'quit' to leave:");
			String alphaCode = sc.nextLine();
			if (!alphaCode.toLowerCase().equals("quit")) {
				Response r = given().get("/alpha/" + alphaCode).then().extract().response();
				int code = r.getStatusCode();
				if (code == 200) {
					String capital = r.path("capital");
					System.out.println(
							"The capital associated with the code " + alphaCode.toUpperCase() + " is " + capital + ".");
				} else {
					System.out.println(
							"Please input existed city code. You could search by ISO 3166-1 2-letter or 3-letter country code.");
				}
			} else {
				input = false;
				System.out.println("Bye, thanks for your query.");
			}
		}
		sc.close();
	}

	@Test
	public void testByLanguage() {
		Scanner sc = new Scanner(System.in);
		boolean input = true;
		while (input) {
			System.out.println("Please input language code or input 'quit' to leave:");
			String lang = sc.nextLine();
			if (!lang.toLowerCase().equals("quit")) {
				Response r = given().get("/lang/" + lang).then().extract().response();
				int code = r.getStatusCode();
				if (code == 200) {
					List<Object> countries = r.jsonPath().getList("name");
					List<Object> capitals = r.jsonPath().getList("capital");
					List<Object> langs = r.jsonPath().getList("languages.name");
					for (int i = 0; i < countries.size(); i++) {
						if (capitals.get(i).toString().length() != 0) {
							System.out.println("The capital of " + countries.get(i) + " is " + capitals.get(i)
									+ ", Where people speak " + langs.get(i));
						} else {
							System.out.println("The capital of " + countries.get(i) + " is not existed in the DB.");
						}
					}
				} else {
					System.out.println(
							"Please input existed language code. You could search by ISO 639-1 language code.");
				}
			} else {
				input = false;
				System.out.println("Bye, thanks for your query.");
			}
		}
		sc.close();
	}
}
